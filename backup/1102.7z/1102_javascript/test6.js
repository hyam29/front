function call1() {
  alert("이곳은 외부 라이브러리 입니다.");
}

function call2() {
  document.write("자바스크립트 연습!");
}

